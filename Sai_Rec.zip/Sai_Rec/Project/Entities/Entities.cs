﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace  Entities
{
    public  class Js_Sign
    {
        public static string UserId { get; set; }

        public  string Password1 { get; set; }

        public  string Password2 { get; set; }

        public  string Securekey { get; set; }
    }

    public  class Er_Sign
    {

        public static string UserId { get; set; }

        public  string Password1 { get; set; }

        public  string Password2 { get; set; }

        public  string Securekey { get; set; }
    }
   
    public class Js_profile
    {
        public string  Name { get; set; }

        public int Experience { get; set; }

        public char Gender { get; set; } 

        public DateTime Dob { get; set; }

        public string Email { get; set; }

        public string Phone { get; set; }
         
        public string Skills { get; set; }

        public string Address { get; set; }

        public string Qualification { get; set; }

        public string Photo { get; set; }

        public string CV { get; set; }       
    }

    public class Er_profile
    {
        public string CompanyName { get; set; }

        public string Clients { get; set; }

        public string Location { get; set; }
    }
    
    public class Job_Profile
    {
        public string JobID { get; set; }

        public int Experience { get; set; }

        public string Designation { get; set; }

        public string Location { get; set; }

        public string Qualification { get; set; }

        public DateTime DateOfOpening { get; set; }

        public double Salary { get; set; }
    }

    public class Job_Application
    {
        public string JobID { get; set; }

        public string JS_UserId { get; set; }
    }
}

