﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using Entities;
using BAL;
using Exceptions;

namespace Home
{
    /// <summary>
    /// Interaction logic for JobSeekerHOME.xaml
    /// </summary>
    public partial class JobSeekerHOME : Window
    {
        Js_Sign js_Sign = new Js_Sign();

        Js_profile js_profile = new Js_profile();

        JobSeekerBAL jobseekerbal = new JobSeekerBAL();

        Job_Profile job_profile = new Job_Profile();

        Job_Application job_application = new Job_Application();

        public static bool parent = false;

        public JobSeekerHOME()
        {
            InitializeComponent();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            
            try
            {
                jshomepage.Visibility = 0;
                gridhome.Visibility = 0;
                RetrieveJobs.Visibility = 0;
                // RetrieveJobs.ItemsSource = jobseekerbal.RetrieveJobs().DefaultView;
            }
            catch (JobSeekerNotValidDataException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (JobSeekerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
        private void btnmyprofile_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //js_profile= jobseekerbal.RetrieveMyProfile();
                //txtfnjs.Text = js_profile.Name;
                //txtemailjs.Text = js_profile.Email;
                //txtphonejs.Text = js_profile.Phone;
                //txtgender.Text = js_profile.Gender.ToString();
                //txtexpjs.Text = js_profile.Experience.ToString();
                //txtdob.Text = js_profile.Dob.ToString();
                //txtskills.Text = js_profile.Skills;
                //txtaddress.Text = js_profile.Address;
                //txtqualification.Text = js_profile.Qualification;


                myprofile.Visibility = 0;
                jshomepage.Visibility = (Visibility)1;
                searchjob.Visibility = (Visibility)1;
            }
            catch (JobSeekerNotValidDataException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (JobSeekerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        

        private void btnmenu_Click(object sender, RoutedEventArgs e)
        {
            myprofile.Visibility = (Visibility)1;
            searchjob.Visibility = (Visibility)1;
            jshomepage.Visibility = 0;
            gridhome.Visibility = 0;
            RetrieveJobs.Visibility = 0;
        }

        private void btnsearchjob_Click(object sender, RoutedEventArgs e)
        {
            RetrieveJobs.Visibility = (Visibility)1;
            searchjob.Visibility =0;
            gridhome.Visibility = (Visibility)1;
        }

        private void btnsearchmenu_Click(object sender, RoutedEventArgs e)
        {
            searchjob.Visibility = (Visibility)1;
            gridhome.Visibility = 0;

        }

        private void EditMyProfile(object sender, RoutedEventArgs e)
        {
            parent = true;
            ProfileFillupWindow p = new ProfileFillupWindow();
            p.Show();
            this.Close();
        }
        private void Sign_Out_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.possition = null;
            Js_Sign.UserId = null;
            Er_Sign.UserId = null;
            MessageBox.Show("Thank You, sign out succes");
            MainWindow p = new MainWindow();
            p.Show();
        }

        private void Search_Job(object sender, RoutedEventArgs e)
        {
            try
            {
                //job_profile.Designation = txtdes.Text;
                //job_profile.Experience =Convert.ToInt32( txtexp.Text);
                //job_profile.Location = cbloc.SelectedItem.ToString();
                //job_profile.Qualification = cbqual.SelectedItem.ToString();
                //job_profile.Salary =Convert.ToInt32( txtsal.Text);
                //job_profile.DateOfOpening = Convert.ToDateTime(dpdoo.Text);

                // RetrieveJobs.ItemsSource= jobseekerbal.SearchJob(job_profile).DefaultView;
                searchjob.Visibility = (Visibility)1;
                jshomepage.Visibility = 0;
                gridhome.Visibility = 0;
                RetrieveJobs.Visibility = 0;
            }
            catch (JobSeekerNotValidDataException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (JobSeekerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void MyApplications(object sender, RoutedEventArgs e)
        {
            try
            {
                RetrieveJobs.ItemsSource = jobseekerbal.MyApplications(Js_Sign.UserId).DefaultView;
            }
            catch (JobSeekerNotValidDataException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (JobSeekerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
