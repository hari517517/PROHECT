﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Entities;
using BAL;
using Exceptions;

namespace Home
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        Js_Sign js_Sign = new Js_Sign();

        Er_Sign er_Sign = new Er_Sign();

       

        EmployerBAL Employerbal = new EmployerBAL();

        JobSeekerBAL Jobseekerbal = new JobSeekerBAL();

        public LoginWindow()
        {
            InitializeComponent();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (MainWindow.possition == "Employer")
            {
                employergrid.Visibility = 0;
                jobseekergrid.Visibility = (Visibility)1;
            }
            else if (MainWindow.possition == "JobSeeker")
            {
                jobseekergrid.Visibility = 0;
                employergrid.Visibility = (Visibility)1;
            }
        }

       

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            RegistrationPage p = new RegistrationPage();
            p.Show(); this.Close();
        }

        private void Login_Btn_click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (MainWindow.possition == "Employer")
                {
                    Er_Sign.UserId = txtUserIder.Text;
                    er_Sign.Password1 = txtpswer.Password;
                    Employerbal.login(er_Sign);
                    //employer home page
                }
                else if (MainWindow.possition == "JobSeeker")
                {
                    Js_Sign.UserId = txtUserIdjs.Text;
                    js_Sign.Password1 = txtpswjs.Password;
                    Jobseekerbal.login(js_Sign);
                    //job seeker home page
                }
            }
            catch (EmployerNotValidDataException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (JobSeekerNotValidDataException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (JobSeekerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Reset_pswd_click(object sender, RoutedEventArgs e)
        {
            PasswordReset p = new PasswordReset();
            p.Show();
        }
    }
}
