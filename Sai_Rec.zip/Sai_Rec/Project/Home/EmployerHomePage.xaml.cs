﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Entities;
using BAL;
using Exceptions;

namespace Home
{
    /// <summary>
    /// Interaction logic for EmployerHomePage.xaml
    /// </summary>
    public partial class EmployerHomePage : Window
    {
        Js_Sign js_Sign = new Js_Sign();

        Er_Sign er_Sign = new Er_Sign();

        Js_profile js_profile = new Js_profile();

        Er_profile er_profile = new Er_profile();

        EmployerBAL Employerbal = new EmployerBAL();

        JobSeekerBAL Jobseekerbal = new JobSeekerBAL();

        Job_Profile job_profile = new Job_Profile();

        public EmployerHomePage()
        {
            InitializeComponent();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Btnback_Click(object sender, RoutedEventArgs e)
        {
            gridsearch.Visibility = Visibility.Visible;
            gdsearchjobdetails.Visibility = Visibility.Hidden;

        }

        private void BtnSearchjob_Click(object sender, RoutedEventArgs e)
        {
            //retrieve jo details
            retrievejobgrid.ItemsSource= Employerbal.RetrieveJOBdetails().DefaultView;
            gdEmployerHome.Visibility = Visibility.Hidden;

            gridsearch.Visibility = Visibility.Visible;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {

        }

        private void Btnaddback_Click(object sender, RoutedEventArgs e)
        {
            gdEmployerHome.Visibility = Visibility.Visible;
            gridadd.Visibility = Visibility.Hidden;
        }

        private void Btnsearch_Click(object sender, RoutedEventArgs e)
        {
            job_profile.JobID = txtjobid1.Text;
            Employerbal.SearchJOBDetails(job_profile.JobID);
            gdsearchjobdetails.Visibility = Visibility.Visible;
            gridsearch.Visibility = Visibility.Hidden;
        }

        private void AddJobDetails(object sender, RoutedEventArgs e)
        {
            gridadd.Visibility = Visibility.Visible;
            gdEmployerHome.Visibility = Visibility.Hidden;
        }

        private void Search_Candidates(object sender, RoutedEventArgs e)
        {
            dgCandidateTable.ItemsSource =Employerbal.RetrieveJobApplicants().DefaultView;
            gdSearchCandidates.Visibility = Visibility.Visible;
            gdEmployerHome.Visibility = Visibility.Hidden;
        }

        private void Btnsearchcanback_Click(object sender, RoutedEventArgs e)
        {
            gdSearchCandidates.Visibility = Visibility.Hidden;
            gdEmployerHome.Visibility = Visibility.Visible;
        }

        private void Btnsearchback_Click(object sender, RoutedEventArgs e)
        {
            gdEmployerHome.Visibility = Visibility.Visible;
            gridsearch.Visibility = Visibility.Hidden;
        }

        private void btnaddjobdetails(object sender, RoutedEventArgs e)
        {
            job_profile.Designation = txtDesgn.Text;
            job_profile.DateOfOpening =Convert.ToDateTime(dpdofopenin.Text);
            job_profile.JobID = txtJobId.Text;
            job_profile.Location = txtloca.Text;
            job_profile.Qualification = cbqual.SelectedValue.ToString();
            job_profile.Salary = Convert.ToDouble(txtsal.Text);
            job_profile.Experience =Convert.ToInt32(txtexp.Text);
            if (Employerbal.AddJobDetails(job_profile))
            {
                MessageBox.Show(" Your Job Details are Added sucessfully..........");
            }
            else
            {
                MessageBox.Show("Sorry your  Job Details are not addeded.........");
            }
           
        }

        private void BtnClearProfile_Click(object sender, RoutedEventArgs e)
        {
            txtDesgn.Text = null;
            dpdofopenin.Text = null;
            txtJobId.Text = null;
            txtloca.Text = null;
            cbqual.Text = null;
            txtsal.Text = null;
            txtexp.Text = null;
        }

        private void BtnCandidateProfile_Click(object sender, RoutedEventArgs e)
        {
            string candidateid = txtCandidateId.Text;
            jobseekerprofile.ItemsSource=Employerbal.RetrieveCandidateProfile(candidateid).DefaultView;
        }
    }
}
