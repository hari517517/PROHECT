﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Entities;
using Exceptions;

namespace DAL1
{
    public class EmployerDAL
    {
        SqlCommand cmd; SqlDataReader dr;SqlConnection con;DataTable dt;
        public bool Register(Er_Sign er_Sign)
        {
            try
            {
                cmd = DatabaseConnection.GenerateCommand();
                cmd.CommandText = "E_rec.er_sign_up_172473";
                cmd.Parameters.AddWithValue("@er_userid", Er_Sign.UserId);
                cmd.Parameters.AddWithValue("@er_password", er_Sign.Password1);
                cmd.Parameters.AddWithValue("@secureanswer", er_Sign.Securekey);
                con = cmd.Connection;
                con.Open();
                int ra = cmd.ExecuteNonQuery();
               
                if (ra > 0)
                { return true; }
                else
                { return false; }
            }
            catch (EmployerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { con.Close(); }

        }

        public bool Profile_Fill(Er_profile er_profile)
        {
            try
            {
                cmd = DatabaseConnection.GenerateCommand();
                cmd.CommandText = "E_rec.er_rst_pswd_172473";
                cmd.Parameters.AddWithValue("@er_userid", Er_Sign.UserId);
                cmd.Parameters.AddWithValue("@company_name", er_profile.CompanyName);
                cmd.Parameters.AddWithValue("@clients", er_profile.Clients);
                cmd.Parameters.AddWithValue("@location", er_profile.Location);
                con = cmd.Connection;
                con.Open();
                int ra = cmd.ExecuteNonQuery();
                con.Close();
                if (ra > 0)
                { return true; }
                return false;
            }
            catch (EmployerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { con.Close(); }
        }

        public DataTable RetrieveJOBdetails()
        {
            try
            {
                cmd = DatabaseConnection.GenerateCommand();
                cmd.CommandText = "usp_retrieve_jobs_for_er";
                cmd.Parameters.AddWithValue("@js_userid", Er_Sign.UserId);


                con = cmd.Connection;
                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt.Load(dr);

                }
                return dt;

            }
            catch (EmployerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { con.Close(); }
        }

        public void SearchJOBDetails(string jobID)
        {
            try
            {
                cmd = DatabaseConnection.GenerateCommand();
                cmd.CommandText = "usp_job_search_for_er";
                cmd.Parameters.AddWithValue("@job_id", jobID);


                con = cmd.Connection;
                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    //Job_Profile job_Profile = new Job_Profile();
                    //job_Profile.JobID = dr[""ToString();
                    //job_Profile.Location = dr[].ToString();
                    //job_Profile.Qualification = dr[].ToString();
                    //job_Profile.Salary = dr[].ToString();
                    //job_Profile.DateOfOpening = dr[].ToString();
                    //job_Profile.Designation = dr[].ToString();
                    //job_Profile.Experience = dr[].ToString();
                }
                

            }
            catch (EmployerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { con.Close(); }
        }

        public bool ResetPassword(Er_Sign er_Sign)
        {
            try
            {
                cmd = DatabaseConnection.GenerateCommand();
                cmd.CommandText = "E_rec.er_rst_pswd_172473";
                cmd.Parameters.AddWithValue("@er_userid", Er_Sign.UserId);
                cmd.Parameters.AddWithValue("@newpswd", er_Sign.Password1);
                cmd.Parameters.AddWithValue("@secure_answer", er_Sign.Securekey);

                con = cmd.Connection;
                con.Open();
                int ra = cmd.ExecuteNonQuery();
                con.Close();
                if (ra > 0)
                { return true; }
                return false;
            }
            catch (EmployerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { con.Close(); }
        }

        public DataTable RetrieveCandidateProfile(string candidateid)
        {
            try
            {
                cmd = DatabaseConnection.GenerateCommand();
                cmd.CommandText = "usp_js_search_er";
                cmd.Parameters.AddWithValue("@js_userid", candidateid);


                con = cmd.Connection;
                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt.Load(dr);

                }
                return dt;

            }
            catch (EmployerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { con.Close(); }
        }

        public DataTable RetrieveJobApplicants()
        {
            try
            {
                cmd = DatabaseConnection.GenerateCommand();
                cmd.CommandText = "E_rec.usp_retrieve_job_applicants";
                cmd.Parameters.AddWithValue("@er_userid", Er_Sign.UserId);
                

                con = cmd.Connection;
                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt.Load(dr);
                   
                }
                return dt;
                
            }
            catch (EmployerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { con.Close(); }
        }

        public bool AddJobDetails(Job_Profile job_profile)
        {
            try
            {
                cmd = DatabaseConnection.GenerateCommand();
                cmd.CommandText = "E_rec.usp_AddJobDetails";
                cmd.Parameters.AddWithValue("@er_userid", Er_Sign.UserId);
                cmd.Parameters.AddWithValue("@job_id", job_profile.JobID);
                cmd.Parameters.AddWithValue("@experience", job_profile.Experience);
                cmd.Parameters.AddWithValue("@designation", job_profile.Designation);
                cmd.Parameters.AddWithValue("@location", job_profile.Location);
                cmd.Parameters.AddWithValue("@qualification", job_profile.Qualification);
                cmd.Parameters.AddWithValue("@date_of_openings", job_profile.DateOfOpening);
                cmd.Parameters.AddWithValue("@salary", job_profile.Salary);

                con = cmd.Connection;
                con.Open();
                int ra = cmd.ExecuteNonQuery();


                if (ra > 0)
                {
                    return true;
                }

                return false;
            }

            catch (EmployerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { con.Close(); }
        }
        public bool login(Er_Sign er_Sign)
        {
            try
            {
                cmd = DatabaseConnection.GenerateCommand();
                cmd.CommandText = "E_rec.er_sign_up_172473";
                cmd.Parameters.AddWithValue("@er_userid", Er_Sign.UserId);
                cmd.Parameters.AddWithValue("@er_password", er_Sign.Password1);

                con = cmd.Connection;
                con.Open();
                dr = cmd.ExecuteReader();
                con.Close();
                if (dr["Result"].ToString() == "YES")
                { return true; }
                else if (dr["Result"].ToString() == "NO")
                { return false; }
                return false;
            }
            catch (EmployerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { con.Close(); }
        }
    }
}
