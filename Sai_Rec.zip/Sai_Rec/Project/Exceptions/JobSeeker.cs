﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptions
{
    public class JobSeekerNotValidDataException : ApplicationException
    {
        public JobSeekerNotValidDataException(string message) : base(message)
        {

        }

    }

    public class JobSeekerException : ApplicationException
    {
        public JobSeekerException() : base()
        {

        }
        public JobSeekerException(string message) : base(message)
        {

        }
    }
}
